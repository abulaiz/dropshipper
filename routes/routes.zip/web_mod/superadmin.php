<?php 

Route::get('/members', function () {
    return view('front_end/layout/superadmin/user');
});

Route::get('/members/{id}', 'UserController@members');

Route::get('/registrant', function () {
    return view('front_end/layout/superadmin/registrant');
});
// Route::post('/user', 'UserController@save')->name('adduser');
// Route::post('/user/edit', 'UserController@edituser')->name('editUser');