<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="horizontal-layout horizontal-menu horizontal-menu-padding 2-columns  menu-expanded" data-open="hover" data-menu="horizontal-menu" data-col="2-columns" ng-app='main'>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="app-content container center-layout mt-2">
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
      <?php if(Session::has('_msg')): ?>
        <?php
          $e = session()->get('_e'); $msg = session()->get('_msg');
        ?>
        <div class="alert <?php echo e($_alert->bg($e)); ?> alert-icon-left alert-dismissible mb-2" role="alert">
          <span class="alert-icon"><i class="<?php echo e($_alert->icon($e)); ?>"></i></span>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <strong><?php echo e($_alert->caption($e)); ?>. </strong><?php echo e($msg); ?>

        </div>
      <?php endif; ?>        
        <div class="content-body">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        </div>
    </div>

    <div class="ovnav" style="display: none;"></div>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script src="../../../app-assets/vendors/js/vendors.min.js"></script>

    <script type="text/javascript" src="../../../app-assets/vendors/js/ui/jquery.sticky.js"></script>

    <script src="../../../app-assets/js/core/app-menu.js"></script>
    <script src="../../../app-assets/js/core/app.js"></script>

    <script src="../../../app-assets/vendors/js/extensions/toastr.min.js" type="text/javascript"></script>

    <script src="../../../assets/js/angular.min.js"></script>
    <script src="../../../assets/js/angular-route.min.js"></script>
 
    <script src="../../../js/config/angularModule.js"></script>
    <script src="../../../js/config/directive.js"></script>

    <script src="../../../app-assets/js/scripts/customizer.js" type="text/javascript"></script>

    <script src="../../../app-assets/new_ext/ambiance/jquery.ambiance.js" type="text/javascript"></script>

    <script src="../../../js/view/notification/navbarController.js"></script>

    <?php echo $__env->yieldContent('customJS'); ?>    
</body>
</html>