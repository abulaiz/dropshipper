<?php $__env->startSection('email', 'active'); ?>

<?php $__env->startSection('content'); ?>

<div class="row" style="margin-bottom: 10px;">
    <div class="col-12">
        <button class="btn btn-primary btn-sm pull-right">
        <i class="fa fa-pencil"></i> Tulis Pesan</button>          
    </div>  
</div>

<section id="tab-pane" ng-controller='mail'>
    <div class ="row">
        <div class="col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div ng-view></div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</section>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJS'); ?>
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/plugins/loaders/loaders.min.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/core/colors/palette-loader.css">

    <script src="../../../js/view/mail/router.js"></script>
    <script src="../../../js/view/mail/mainController.js"></script>
    <script src="../../../js/view/mail/mailboxController.js"></script>
    <script src="../../../js/view/mail/detailController.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>