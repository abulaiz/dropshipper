<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Libs\Mail;
use Auth;

class MailController extends Controller
{
	// $type = 'inbox' / 'sent'
    public function index(Request $req)
    {
    	$flag = Auth::user()->hasRole('member') ? 'M' : 'A';
    	$user_id = Auth::user()->id;
        $count = isset($req->count) ? $req->count : null;
    	if($req->type == 'inbox'){
    		$data = Mail::getInstance()->readInbox($flag, $user_id, ['file' => $req->last_file, 'id' => $req->last_id]);
    	} else {
    		$data = Mail::getInstance()->readOutbox($flag, $user_id, ['file' => $req->last_file, 'id' => $req->last_id]);
    	}

    	return response()->json($data);	
    }

    public function read(Request $req){
        $flag = Auth::user()->hasRole('member') ? 'M' : 'A';
        $user_id = Auth::user()->id;      
        $data = Mail::getInstance()->detailMail($flag, $user_id, $req->id, $req->file);
        
        if($req->file == 'inbox')
            Mail::getInstance()->markAsReadInbox($flag, $user_id, $req->id);
        
        return response()->json($data);   
    }
}
