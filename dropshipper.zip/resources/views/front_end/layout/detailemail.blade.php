@extends('layouts.master')
@section('detailemail', 'active')

@section('content')

<section id="tab-pane email">
    <div class ="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-content">

<!-- Start Icon Atas -->
<div class="card email-app-details d-none d-lg-block">
    <div class="card-content">
        <div class="email-app-options card-body">
            <div class="row">
                <div class="col-md-6 col-12">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="tooltip" data-placement="top" data-original-title="Replay"><i class="fa fa-reply"></i></button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="tooltip" data-placement="top" data-original-title="Replay All"><i class="fa fa-reply-all"></i></button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="tooltip" data-placement="top" data-original-title="Report SPAM"><i class="ft-alert-octagon"></i></button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="tooltip" data-placement="top" data-original-title="Delete"><i class="ft-trash-2"></i></button>
                    </div>                    
                </div>
                <div class="col-md-6 col-12 text-right">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="tooltip" data-placement="top" data-original-title="Previous"><i class="fa fa-angle-left"></i></button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="tooltip" data-placement="top" data-original-title="Next"><i class="fa fa-angle-right"></i></button>
                    </div>   
                </div>
            </div>
        </div>
<!-- End Icon Atas -->

<!-- Start SUBJEK -->
    <div class="email-app-title card-body">
            <h3 class="list-group-item-heading">Project ABC Status Report</h3>
            <p class="list-group-item-text"><span class="primary"><span class="badge badge-primary">Previous</span> <i class="float-right font-medium-3 ft-star warning"></i></span></p>
        </div>
<!-- End Subjek -->

<div class="media-list">
            <div id="headingCollapse1"  class="card-header p-0">
                <a data-toggle="collapse" href="#collapse1" aria-expanded="true" aria-controls="collapse1" class="collapsed email-app-sender media border-0 bg-blue-grey bg-lighten-5">
                    
                    <div class="media-left pr-1">
                        <span class="avatar avatar-md"><img class="media-object rounded-circle" src="../../../app-assets/images/portrait/small/avatar-s-1.png" alt="Generic placeholder image"></span>
                    </div>
                    <div class="media-body w-100">
                        <h6 class="list-group-item-heading">John Doe</h6>
                        <p class="list-group-item-text">Can you please provide me ABC Status Report. <span class="float-right text muted">12 July</span></p>
                    </div>

                </a>
            </div>

            <div id="collapse1" role="tabpanel" aria-labelledby="headingCollapse1" class="card-collapse collapse" aria-expanded="true">
                <div class="card-content">
                    <div class="card-body">
                        <p>Hi Wayne,</p>
                        <p>Can you please provide me ABC Status Report.</p>
                        <p>Gmail Material Design Concept. Please check the full project on Behance. Hope that will be fine for you.</p>
                        <p>Thanks for your consideration !</p>
                        <p>Regards,<br/>John</p>
                    </div>
                </div>
            </div>
            
            <div id="headingCollapse2"  class="card-header p-0">
                <a data-toggle="collapse" href="#collapse2" aria-expanded="false" aria-controls="collapse2" class="email-app-sender media border-0">
                    
                    <div class="media-left pr-1">
                        <span class="avatar avatar-md"><img class="media-object rounded-circle" src="../../../app-assets/images/portrait/small/avatar-s-7.png" alt="Generic placeholder image"></span>
                    </div>
                    <div class="media-body w-100">
                        <h6 class="list-group-item-heading">Wayne Burton</h6>
                        <p class="list-group-item-text">to me <span>Today</span>
                            <span class="float-right">
                                <i class="fa fa-reply mr-1"></i>
                                <i class="fa fa-arrow-right mr-1"></i>
                                <i class="fa fa-ellipsis-v"></i>
                            </span>
                        </p>
                    </div>

                </a>
            </div>
            <div id="collapse2" role="tabpanel" aria-labelledby="headingCollapse2" class="card-collapse" aria-expanded="false">
                <div class="card-content">
                    <div class="email-app-text card-body">
                        <div class="email-app-message">
                            <p>Hi John,</p>
                            <p>Thanks for your feedback ! Here's a new layout for a new Robust Admin theme.</p>
                            <p>We will start the new application development soon once this will be completed, I will provide you more details after this Saturday. Hope that will be fine for you.</p>
                            <p>Hope your like it, or feel free to comment, feedback or rebound !</p>
                            <p>Cheers~</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="email-app-text-action card-body">

            </div>
        </div>

                    </div>
                </div>
            </div>
        </div>
    </div> 
</section>

   
@endsection