    <div class="card-content" ng-controller='detail'>

        <div class="email-app-title card-body">
            <h3 class="list-group-item-heading">{* subject *}</h3>
        </div>

        <div class="media-list">            
            <div id="headingCollapse2"  class="card-header p-0 ">
                <div class="email-app-sender media border-0">
                    <div class="media-left pr-1">
                        <span class="avatar avatar-md">
                            <span class="media-object rounded-circle text-circle ng-class:avatarColour();">{* flag == 'M' ? name[0].toUpperCase() : flag *}</span>
                        </span>
                    </div>
                    <div class="media-body w-100">
                        <h6 class="list-group-item-heading">{* name *}</h6>
                        <p class="list-group-item-text">{* getDate() *}
                            <span class="float-right">
<!--                                 <i class="fa fa-reply mr-1"></i>
                                <i class="fa fa-arrow-right mr-1"></i>
                                <i class="fa fa-ellipsis-v"></i> -->
                            </span>
                        </p>
                    </div>
                </div>
            </div>
            <hr>
            <div id="collapse2" role="tabpanel" aria-labelledby="headingCollapse2" class="card-collapse" aria-expanded="false">
                <div class="card-content">
                    <div class="email-app-text card-body">
                        <div class="loader-wrapper" ng-show='onload'>
                          <div class="loader-container">
                            <div class="ball-pulse loader-secondary">
                              <div></div>
                              <div></div>
                              <div></div>
                            </div>
                          </div>
                        </div>                        
                        <div class="email-app-message" ng-hide='onload'>
                            {* content *}
                        </div>
                    </div>
                </div>
            </div>
            <div class="email-app-text-action card-body">

            </div>
        </div>
    </div>