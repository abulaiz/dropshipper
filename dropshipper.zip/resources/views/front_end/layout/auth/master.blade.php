<!DOCTYPE html>
<html>
<head>
	@include('layouts.head')
</head>
	@yield('content')
</html>